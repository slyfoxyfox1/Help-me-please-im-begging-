public class Hotel {

    //CLASS CONSTANTS
    private static final double ROOM_RATE = 79.95;
    private static final double TAX_RATE = 6.5;
    private static final double TELEPHONE = 5.75;
    private static final double MEAL_COST = 12.95;
    private static final double TIP_RATE = 0.075;

    //INSTANCE VARIABLES
    private int noOfNights;
    private int  noOfGuest;
    private double amountDue;
    private double meal;
    private double tax;
    private double subtotal;
    private double total;
    private double tip;
    private String roomNumber;
    private double completeTotal;

    //CONSTRUCTORS
    public Hotel (String room){
        roomNumber = room;
        noOfGuest = 1;
        noOfNights = 1;
    }

    public Hotel (String room, int nights){
        this(room);
        noOfNights = nights;
    }
    public Hotel (String room, int nights, int guest){
        this(room, nights);
        noOfGuest = guest;
    }
    //METHODS
    /*public void addNights(int nights){
        noOfNights += nights;
    }
    public void addGuest(int guest){
        noOfGuest += guest;
    }*/
    public void calculate(){
        amountDue = ROOM_RATE*noOfNights*noOfGuest;
        tax = amountDue * TAX_RATE/100;
        subtotal =amountDue+tax;
        meal = MEAL_COST*noOfNights;
        tip = TIP_RATE*(subtotal+meal+TELEPHONE);
        total = subtotal+TELEPHONE+meal+tip;

    }
    public String getRoomNo(){return roomNumber;}
    public double getRoomRate(){return ROOM_RATE;}
    public int getNights(){return noOfNights;}
    public int getGuest(){return noOfGuest;}
    public double getRoomCost(){return amountDue;}
    public double getTax(){return tax;}
    public double getSubtotal(){return subtotal;}
    public double getTelephone(){return TELEPHONE;}
    public double getMealCost(){return meal;}
    public double getTip(){return tip;}
    public double getTotal(){return total;}

}
