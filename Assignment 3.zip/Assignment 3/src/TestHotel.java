
import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.Date;

public class TestHotel {
    public static void main(String[]arg){

        NumberFormat f = NumberFormat.getCurrencyInstance();

        Hotel c1 = new Hotel("12-B",3,1);
        c1.calculate();
        displayReceipt(c1, f);

        Hotel c2 = new Hotel("12-C",2,4);
        c2.calculate();
        displayReceipt(c2, f);

        Hotel c3 = new Hotel("12-D",2,2);
        c3.calculate();
        displayReceipt(c3, f);
    }

    public static void displayReceipt(Hotel h, NumberFormat f){
        Date d = new Date();
        DateFormat df = DateFormat.getDateInstance();

        //Output Receipt
        System.out.println("\nThe ABC Cheap Lodging, Inc");
        System.out.println("\tDate: \t" + df.format(d));
        System.out.println("Room #       " +h.getRoomNo());
        System.out.println("Room Rate      " +f.format(h.getRoomRate()));
        System.out.println("Length of Stay      " +h.getNights() + " night(s)");
        System.out.println("No. of Guest      " +h.getGuest());
        System.out.println("Room Cost      " +f.format(h.getRoomCost()));
        System.out.println("Tax 6.5%      " +f.format(h.getTax()));
        System.out.println("Subtotal      " +f.format(h.getSubtotal()));
        System.out.println("Telephone      " +f.format(h.getTelephone()));
        System.out.println("Meal Charges      " +f.format(h.getMealCost()));
        System.out.println("Tip      " +f.format(h.getTip()));
        System.out.println("TOTAL AMOUNT DUE.........." +f.format(h.getTotal()));
        System.out.println("Thanks for staying at The ABC Cheap Lodging, Inc");
        System.out.println("\nPlease come again!!!");
    }
    /*static void displayOfficialTotal(Hotel c, NumberFormat f){
        System.out.println("\n\t\tOfficial Use Only");
        System.out.println("\tToday's Summary");
        System.out.println("\tRoom......$" +c.getRoomCost());
        System.out.println("\tTelephone......");
        System.out.println("\tMeal......");
        System.out.println("\tTips......");
        System.out.println("\tTax......");
        System.out.println("\t______________________________________");
        System.out.println("\tGross Transaction...");
        System.out.println("Process Completed");
    }*/
}