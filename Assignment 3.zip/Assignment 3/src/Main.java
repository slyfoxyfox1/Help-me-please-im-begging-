/*

import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.Date;


public class Main {
    public static void main(String[] args) {
        //Variables
        Date d = new Date();
        DateFormat df = DateFormat.getDateInstance();

        //Output Receipt
        System.out.println("\nThe ABC Cheap Lodging, Inc");
        System.out.println("\tDate: \t" + df.format(d));
        System.out.println("Room #");
        System.out.println("Room Rate");
        System.out.println("Length of Stay");
        System.out.println("No. of Guest");
        System.out.println("Room Cost");
        System.out.println("Tax 6.5%");
        System.out.println("\tSubtotal\t");
        System.out.println("Telephone");
        System.out.println("Meal Charges");
        System.out.println("Tip");
        System.out.println("TOTAL AMOUNT DUE..........");
        System.out.println("Thanks for staying at The ABC Cheap Lodging, Inc");
        System.out.println("Please come again!!!");
        System.out.println("\nThe ABC Cheap Lodging, Inc");
        System.out.println("\tDate: \t" + df.format(d));
        System.out.println("Room #");
        System.out.println("Room Rate");
        System.out.println("Length of Stay");
        System.out.println("No. of Guest");
        System.out.println("Room Cost");
        System.out.println("Tax 6.5%");
        System.out.println("\tSubtotal\t");
        System.out.println("Telephone");
        System.out.println("Meal Charges");
        System.out.println("Tip");
        System.out.println("TOTAL AMOUNT DUE..........");
        System.out.println("Thanks for staying at The ABC Cheap Lodging, Inc");
        System.out.println("Please come again!!!");
        System.out.println("\nThe ABC Cheap Lodging, Inc");
        System.out.println("\tDate: \t" + df.format(d));
        System.out.println("Room #");
        System.out.println("Room Rate");
        System.out.println("Length of Stay");
        System.out.println("No. of Guest");
        System.out.println("Room Cost");
        System.out.println("Tax 6.5%");
        System.out.println("\tSubtotal\t");
        System.out.println("Telephone");
        System.out.println("Meal Charges");
        System.out.println("Tip");
        System.out.println("TOTAL AMOUNT DUE..........");
        System.out.println("Thanks for staying at The ABC Cheap Lodging, Inc");
        System.out.println("\tPlease come again!!!\t");
        System.out.println("\nOfficial Use Only");
        System.out.println("Today's Summary");
        System.out.println("Room......");
        System.out.println("Telephone......");
        System.out.println("Meal......");
        System.out.println("Tips......");
        System.out.println("Tax......");
        System.out.println("______________________________________");
        System.out.println("Gross Transaction...");
        System.out.println("Process Completed");

    }
}*/